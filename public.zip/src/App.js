import React, { Component } from 'react';
import './App.css';
import {connect} from 'react-redux';
import reducer from './reducers/reducer'
import {fetchData, postData} from './actions/action'



class App extends Component {
  constructor(props){
    console.log(props);
    debugger;
    super(props)
    this.state = {input :[]}

  }

    componentDidMount(dispatch) {
        this.props.fetchData()
    }

  render(){
    return (
      <div className="App">
          Demo App
          <input type='text'   onBlur = {(e) => this.props.onBlurInput(e.target.value)} />
          <div>Print Data </div>

          
        
      </div>
    )
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    onBlurInput: (data) => {
      dispatch(postData(data))
    }, fetchData: () => {
      dispatch(fetchData())
    }
  }
}



const mapStateToProps=(state, ownProps)=> {
  console.log(state);
  return 
  {
    displayData: state
  }
}

export default connect(mapStateToProps,mapDispatchToProps)(App);
