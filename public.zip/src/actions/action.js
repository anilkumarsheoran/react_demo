export  const postData =(data) => {
	return {
		type: 'POST_DATA',
		data
	}
}

export const fetchData = (data) => {

	return {type: 'GET_DATA',
	data
	}
}


export const successFetchData = (data) =>{
	return {
		type: 'DISPLAY_DATA',
		data
	}
}
