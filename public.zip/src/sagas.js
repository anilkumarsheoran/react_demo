import { call, put, takeEvery, takeLatest } from 'redux-saga/effects'
import {fetchAPI, postAPI} from './api'

function* fetchSaga(action) {
   try {
   
      const data = yield call(fetchAPI	);
      yield put({type: "DISPLAY_DATA", data});
   } catch (e) {
      yield put(alert('some thing went wrong'));
   }
}

function* postSaga(action) {
   try {
   
      const data = yield call(postAPI, action.data);
    
   } catch (e) {
      yield put(alert('some thing went wrong'));
   }
}

function* saga(){
	try{
		yield takeLatest( "GET_DATA", fetchSaga);
		yield takeLatest("POST_DATA", postSaga)
	}catch(e){
		  yield put(alert('some thing went wrong'));
	}
}

export default saga