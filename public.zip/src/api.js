  
const url = "http://localhost:5000/comment"




export   function fetchAPI(){
	return (fetch(url)
  		.then((response) => response.json()) )	
}

export function postAPI(data){
	debugger;
	return(fetch('https://jsonplaceholder.typicode.com/posts', {
    method: 'POST',
    body: JSON.stringify({
      title: data,
      body: 'bar',
      userId: 1
    }),
    headers: {
      "Content-type": "application/json; charset=UTF-8"
    }
  })

		)
}